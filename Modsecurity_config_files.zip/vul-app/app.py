from flask import Flask, request, render_template, redirect, url_for, session, make_response
import sqlite3
import os
import pickle
import subprocess
from hashlib import md5

app = Flask(__name__)
app.secret_key = 'insecure_secret_key_123'  # Hardcoded secret key

# Initialize a vulnerable SQLite database
def init_db():
    if not os.path.exists('vulnerable.db'):
        conn = sqlite3.connect('vulnerable.db')
        cursor = conn.cursor()
        cursor.execute('CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT, password TEXT, is_admin INTEGER)')
        cursor.execute("INSERT INTO users (username, password, is_admin) VALUES ('admin', 'password123', 1)")
        cursor.execute("INSERT INTO users (username, password, is_admin) VALUES ('user', 'letmein', 0)")
        cursor.execute("CREATE TABLE passwords (user_id INTEGER, reset_token TEXT)")
        conn.commit()
        conn.close()

init_db()

@app.route('/')
def home():
    return render_template('index.html', session=session, user=session.get('user'))

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    password_hash = md5(password.encode()).hexdigest()
    conn = sqlite3.connect('vulnerable.db')
    cursor = conn.cursor()
    query = f"SELECT * FROM users WHERE username = '{username}' AND password = '{password}'"
    cursor.execute(query)
    user_data = cursor.fetchone()
    conn.close()
    if user_data:
        user = {'id': user_data[0], 'username': user_data[1], 'is_admin': user_data[3]}
        session['user'] = user
        return render_template('index.html', message=f"Welcome {user['username']}! You are logged in.", user=user)
    else:
        return render_template('index.html', message="Login failed!")

@app.route('/search')
def search():
    query = request.args.get('query', '')
    results = []
    if query:
        results = [f"Result for {query}", f"Another result for {query}"]
        if query.startswith('!'):
            try:
                cmd_output = subprocess.check_output(query[1:], shell=True, stderr=subprocess.STDOUT)
                results.append(f"Command output: {cmd_output.decode()}")
            except Exception as e:
                results.append(f"Command failed: {str(e)}")
    return render_template('index.html', results=results)

@app.route('/upload', methods=['POST'])
def upload():
    if 'file' not in request.files:
        return render_template('index.html', message="No file uploaded!")
    file = request.files['file']
    if file.filename == '':
        return render_template('index.html', message="No file selected!")
    upload_dir = 'uploads'
    if not os.path.exists(upload_dir):
        os.makedirs(upload_dir)
    filepath = os.path.join(upload_dir, file.filename)
    file.save(filepath)
    if request.args.get('custom_path'):
        custom_path = request.args.get('custom_path')
        file.save(os.path.join(upload_dir, custom_path, file.filename))
    return render_template('index.html', message=f"File uploaded successfully to {filepath}!")

@app.route('/profile')
def profile():
    user_id = request.args.get('user_id')
    conn = sqlite3.connect('vulnerable.db')
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM users WHERE id = {user_id}")
    user_data = cursor.fetchone()
    conn.close()
    if user_data:
        return render_template('index.html', message=f"Profile for {user_data[1]} (Admin: {bool(user_data[3])})")
    else:
        return render_template('index.html', message="User not found!")

@app.route('/reset_password', methods=['POST'])
def reset_password():
    username = request.form['username']
    reset_token = md5(username.encode()).hexdigest()
    conn = sqlite3.connect('vulnerable.db')
    cursor = conn.cursor()
    cursor.execute(f"SELECT id FROM users WHERE username = '{username}'")
    user = cursor.fetchone()
    if user:
        cursor.execute(f"INSERT INTO passwords VALUES ({user[0]}, '{reset_token}')")
        conn.commit()
        conn.close()
        return render_template('index.html', message=f"Reset token: {reset_token}")
    else:
        conn.close()
        return render_template('index.html', message="User not found!")

@app.route('/remember_me', methods=['POST'])
def remember_me():
    remember = request.form.get('remember') == 'true'
    if remember and 'user' in session:
        serialized_user = pickle.dumps(session['user'])
        resp = make_response(render_template('index.html', message="Remember me set!"))
        resp.set_cookie('remember_me', serialized_user.hex())
        return resp
    return render_template('index.html', message="Remember me not set")

@app.route('/admin')
def admin_panel():
    if 'user' in session and session['user'].get('is_admin'):
        return render_template('index.html', message="Welcome to Admin Panel!")
    else:
        return render_template('index.html', message="Regular user admin panel view")

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')

