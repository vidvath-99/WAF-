from flask import Flask, request, render_template, redirect, url_for, session, make_response
import sqlite3
import os
import pickle
import subprocess
from hashlib import md5

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, 'vulnerable.db')

app = Flask(__name__)
app.secret_key = 'insecure_secret_key_123'

# Initialize the vulnerable DB
def init_db():
    if not os.path.exists('vulnerable.db'):
        basedir = os.path.abspath(os.path.dirname(__file__))
        conn = sqlite3.connect(os.path.join(basedir, 'vulnerable.db'))
        cursor = conn.cursor()
        cursor.execute('CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT, password TEXT, is_admin INTEGER)')
        cursor.execute("INSERT INTO users (username, password, is_admin) VALUES ('admin', 'password123', 1)")
        cursor.execute("INSERT INTO users (username, password, is_admin) VALUES ('user', 'letmein', 0)")
        cursor.execute("CREATE TABLE passwords (user_id INTEGER, reset_token TEXT)")
        conn.commit()
        conn.close()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    message = ""
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        query = f"SELECT * FROM users WHERE username = '{username}' AND password = '{password}'"
        cursor.execute(query)
        user_data = cursor.fetchone()
        conn.close()
        if user_data:
            user = {'id': user_data[0], 'username': user_data[1], 'is_admin': user_data[3]}
            session['user'] = user
            message = f"Welcome {user['username']}! You are logged in."
        else:
            message = "Login failed!"
    return render_template('login.html', message=message, user=session.get('user'))

@app.route('/search', methods=['GET'])
def search():
    query = request.args.get('query', '')
    results = []
    if query:
        results = [f"Result for {query}", f"Another result for {query}"]
        if query.startswith('!'):
            try:
                cmd_output = subprocess.check_output(query[1:], shell=True, stderr=subprocess.STDOUT)
                results.append(f"Command output: {cmd_output.decode()}")
            except Exception as e:
                results.append(f"Command failed: {str(e)}")
    return render_template('search.html', results=results, query=query)

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    message = ""
    if request.method == 'POST':
        if 'file' not in request.files:
            message = "No file uploaded!"
        else:
            file = request.files['file']
            if file.filename == '':
                message = "No file selected!"
            else:
                upload_dir = 'uploads'
                if not os.path.exists(upload_dir):
                    os.makedirs(upload_dir)
                filepath = os.path.join(upload_dir, file.filename)
                file.save(filepath)
                if request.args.get('custom_path'):
                    custom_path = request.args.get('custom_path')
                    custom_path_full = os.path.join(upload_dir, custom_path)
                    os.makedirs(custom_path_full, exist_ok=True)
                    file.save(os.path.join(custom_path_full, file.filename))
                message = f"File uploaded successfully to {filepath}!"
    return render_template('upload.html', message=message)

@app.route('/profile')
def profile():
    user_id = request.args.get('user_id')
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM users WHERE id = {user_id}")
    user_data = cursor.fetchone()
    conn.close()
    if user_data:
        message = f"Profile for {user_data[1]} (Admin: {bool(user_data[3])})"
    else:
        message = "User not found!"
    return render_template('profile.html', message=message)

@app.route('/reset_password', methods=['GET', 'POST'])
def reset_password():
    message = ""
    if request.method == 'POST':
        username = request.form['username']
        reset_token = md5(username.encode()).hexdigest()
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute(f"SELECT id FROM users WHERE username = '{username}'")
        user = cursor.fetchone()
        if user:
            cursor.execute(f"INSERT INTO passwords VALUES ({user[0]}, '{reset_token}')")
            conn.commit()
            message = f"Reset token: {reset_token}"
        else:
            message = "User not found!"
        conn.close()
    return render_template('reset_password.html', message=message)

@app.route('/remember_me', methods=['GET', 'POST'])
def remember_me():
    message = ""
    if request.method == 'POST':
        remember = request.form.get('remember') == 'true'
        if remember and 'user' in session:
            serialized_user = pickle.dumps(session['user'])
            resp = make_response(render_template('remember_me.html', message="Remember me set!"))
            resp.set_cookie('remember_me', serialized_user.hex())
            return resp
        else:
            message = "Remember me not set"
    return render_template('remember_me.html', message=message)

@app.route('/admin')
def admin_panel():
    message = ""
    if 'user' in session and session['user'].get('is_admin'):
        message = "Welcome to Admin Panel!"
    else:
        message = "Regular user admin panel view"
    return render_template('admin.html', message=message)

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('index'))

if __name__ == '__main__':
    init_db()
    app.run(debug=True, host='0.0.0.0')

